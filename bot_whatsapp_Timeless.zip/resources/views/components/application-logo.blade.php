<img src="{{ asset('svg/logo.svg') }}" alt="Logo" width="50" height="50">
